truncate('hello world', 8)이 'hello wo…'(9자)를 돌려줍니다. 붙인 '…'까지 합쳐 8자여야 합니다. 짧은 글에도 '…'가 붙습니다. (src/text.js)

## 일의 성격 제안

버그 고침

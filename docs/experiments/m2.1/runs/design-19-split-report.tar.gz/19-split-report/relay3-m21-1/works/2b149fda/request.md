src/report.js의 buildReport가 CSV 읽기, 분류별 집계, 출력 글 만들기를 한 함수에서 다 한다. src/csv.js의 parseCsv(text), src/summary.js의 summarize(rows), src/format.js의 formatReport(summary)로 나누고, buildReport(text)는 그 셋을 차례로 부르게 해 달라. 동작은 지금과 같아야 한다(월말 정산 스크립트가 buildReport의 출력을 그대로 쓴다).

## 일의 성격 제안

리팩터링

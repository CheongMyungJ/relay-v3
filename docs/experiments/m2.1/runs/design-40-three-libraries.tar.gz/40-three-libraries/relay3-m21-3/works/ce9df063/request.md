공용 도구 세 개를 이번에 같이 만들어 주세요. 서로 관계없는 모듈입니다. (1) src/csv.js에 parseCsv(text): CSV 글을 칸 목록의 목록으로 읽는다. 큰따옴표로 감싼 칸(안의 쉼표, 줄바꿈, ""는 따옴표 하나), LF와 CRLF를 받고, 빈 칸은 빈 글로 남긴다. toCsv로 쓴 것을 읽으면 그대로여야 한다. (2) src/money.js에 formatKrw(amount)와 parseKrw(text): ₩1,234,567 꼴로 쓰고 읽는다. 음수는 -₩1,500처럼 기호 앞에 -. parseKrw는 기호와 쉼표, 앞뒤 공백을 받고 읽지 못하면 null. (3) src/workdays.js에 workdaysBetween(start, end, holidays = [])와 addWorkdays(date, n, holidays = []): 날짜는 'YYYY-MM-DD' 글이고, 주말과 공휴일(holidays 목록)을 뺀 근무일을 센다/더한다. 세 모듈은 리뷰하는 사람이 달라서 모듈마다 브랜치를 따로 두고 싶고, 셋 다 이번에 끝내고 싶어요.

## 일의 성격 제안

기능

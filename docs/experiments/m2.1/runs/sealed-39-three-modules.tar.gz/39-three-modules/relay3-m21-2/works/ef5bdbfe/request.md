세 가지를 이번에 같이 해 주세요. (1) src/sales.js에 monthlyTotals(sales): 달(YYYY-MM)마다 금액 합계를 [{ month, total }]로, 달 오름차순. (2) src/inventory.js에 lowStock(items, threshold = 5): 재고가 기준 이하인 품목을 수량이 적은 차례로(같으면 이름 차례). (3) src/members.js에 exportMembers(members): 회원 목록을 CSV(id,name,email 머리글)로 내보내되 이메일은 개인정보라 앞 한 글자만 보이게 가린다(kim@example.com → k***@example.com).

## 일의 성격 제안

기능

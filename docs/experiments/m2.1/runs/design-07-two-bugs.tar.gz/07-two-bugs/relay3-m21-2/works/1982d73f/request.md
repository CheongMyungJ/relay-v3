src/text.js의 truncate('hello world', 8)이 'hello wo…'(9자)를 돌려줍니다. 붙인 '…'까지 합쳐 8자여야 합니다. 또 짧은 글에도 '…'가 붙는 문제가 있습니다.

## 일의 성격 제안

버그 고침

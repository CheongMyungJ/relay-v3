src/text.js의 truncate('hello world', 8)이 'hello wo…'(9자)를 돌려줍니다. 붙인 '…'까지 8자여야 합니다. 그리고 짧은 글에도 '…'가 붙는 버그도 있습니다. 이 truncate 버그만 고쳐 주세요.

## 일의 성격 제안

버그 고침
